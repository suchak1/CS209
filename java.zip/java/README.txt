SPACE makes Mario float upwards

+/- increase and decrease the animation speed 