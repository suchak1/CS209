Game 4:
We realized the win condition (star) may be off screen on some displays, so we updated the star position to be on-screen. Sorry for the confusion, please grade this accordingly. Thank you!

Game 5:
Core Features:
 - Arrow keys to move Mario in any direction.
 - W&Q rotate mario clockwise and counter-clockwise respectively.
 - A&S make Mario scale up and down respectively.
 - Z&X make Mario more and less transparent respectively.
 - IJKL move Mario's pivotPoint like arrow keys.
 - Mario and other objects with physics (e.g. soccer ball) experience gravity.
 - Mario takes damage if he collides with some objects (e.g. cactus).

Additional Features:
 - Mario will accelerate if a given key is held (quickly up to 5x normal speed).
 - Hold 't' to activate turbo boost; Mario will move really fast.
 - Mario can push objects with physics (e.g. soccer ball).
 - A spark effect appears when Mario collides with harmful objects.


To Note: collision resolution with rotation and scaling is imperfect.